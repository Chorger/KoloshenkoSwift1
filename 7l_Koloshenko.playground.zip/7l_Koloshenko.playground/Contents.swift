import Cocoa

extension Array {
    var countMinusOne : Int { return (count - 1) }
}

enum ArrayErrors : Error {
    case arrayIsEmpty
    case arrayIsLessThan90Percent
}

struct Queue<T> {
    private var TrimExcess : Int = 0
    private var elements : [T] = []
    
    mutating func clear() { elements = [] }
    
    mutating func enqueue(newElement : T) {
        elements.append(newElement)
    }
    
    mutating func cpuLoadDequeue() throws -> T {
        try exceptionIfEmpty(arrayToCheck: elements)
        return elements.removeFirst()
    }
    
    func peek() throws -> T {
        try exceptionIfEmpty(arrayToCheck: elements)
        return elements[0]
    }
    
    /**
     Сравнивает очередь с данным массивом и
     возвращает массив с совпадающими элементами
     */
    func compareArrays(array : [T], filter : (T, T) -> Bool) throws -> [T] {
        try exceptionIfEmpty(arrayToCheck: array)
        try exceptionIfEmpty(arrayToCheck: elements)
        var arrayToReturn : [T] = []
        
        if elements.count >= array.count {
            for index in 0...elements.countMinusOne {
                for kindex in 0...array.countMinusOne {
                    if filter(elements[index], array[kindex]) {
                        arrayToReturn.append(elements[index])
                    }
                }
            }
        }
        else {
            for index in 0...array.countMinusOne {
                for kindex in 0...elements.countMinusOne {
                    if filter(array[index], elements[kindex]) {
                        arrayToReturn.append(elements[kindex])
                    }
                }
            }
        }
        return arrayToReturn
    }
    
    /** Если замыкание выдаёт true, элемент удаляется. */
    mutating func filter(filter : (T) -> Bool) throws {
        try exceptionIfEmpty(arrayToCheck: elements)
        var index : Int = 0
        while index <= elements.countMinusOne {
            if filter(elements[index]) {
                elements.remove(at: index)
            }
            else { index += 1 }
        }
    }
    
    /** Ограничивает объём массива до запрошенного значения,
        если число меньше, чем 90% от текущей длины массива */
    mutating func trimExcess(number : Int) throws {
        try exceptionIfEmpty(arrayToCheck: elements)
        guard Double(number) < (Double(elements.count) * 0.9)
            else {
                throw ArrayErrors.arrayIsLessThan90Percent
        }
    }
    
    /** Выбрасывает ошибку, если отправлен запрос к пустому архиву. */
    func exceptionIfEmpty(arrayToCheck : [T]) throws {
        if arrayToCheck.isEmpty { throw ArrayErrors.arrayIsEmpty }
    }
    
    /** Возвращает элементы с данными индексами */
    subscript(givenIndexes : Int ...) -> [T] {
        var arrayToReturn : [T] = []
        
        for index in givenIndexes where index < elements.count {
            arrayToReturn.append(elements[index])
        }
        
        return arrayToReturn
    }
    
    /**
     Возвращает элемент с данным индексом или nil,
     если элемента с таким индексом нет.
     */
    subscript(givenIndex : Int) -> T? {
        if givenIndex < elements.count && givenIndex >= 0 {
            return elements[givenIndex]
        }
        else {
            return nil
        }
    }
}
do {
    var firstQueue = Queue<Int>()
    firstQueue.enqueue(newElement: 10)
    firstQueue.enqueue(newElement: 100)
    firstQueue.enqueue(newElement: 234)
    print(try firstQueue.cpuLoadDequeue())
    print(try firstQueue.peek())
    print(try firstQueue.compareArrays(array: [234], filter: { $0 == $1 } ))
    try firstQueue.filter(filter: { $0 % 2 == 0} )


    print(try firstQueue.peek())
    print(firstQueue[1] ?? "no such element")
}
catch ArrayErrors.arrayIsEmpty {
    print("Архив пуст, добавьте чего-нибудь сперва!")
}
catch ArrayErrors.arrayIsLessThan90Percent {
    print("Слишком больше число, попробуйте меньше.")
}
