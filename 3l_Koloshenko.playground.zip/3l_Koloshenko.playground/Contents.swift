import Cocoa

struct Car {
    private let color : String
    private let brand : String
    private let manufactureDate : Int
    private let trunkVolume : Int
    private var engineIsOn : Bool
    private var windowsOpened : Bool
    private var trunkIsOpened : Bool
    private var carIsElectric : Bool
    private var nonStockExhaust : Bool
    private var exhaustIsOpened : Bool
    private var usedTrunkVolume : Int
    private let maximumAmountOfPassengers : Int
    private var passengersFullName : [(String, String, String)]
    private var amountOfPassengers : Int
    
    init(color : String, brand : String, manufactureDate : Int,
         trunkVolume : Int, carIsElectric : Bool,
         maximumAmountOfPassengers : Int, nonStockExhaust : Bool) {
        self.color = color
        self.brand = brand
        self.manufactureDate = manufactureDate
        self.trunkVolume = trunkVolume
        self.engineIsOn = false
        self.windowsOpened = false
        self.carIsElectric = carIsElectric
        self.trunkIsOpened = false
        self.nonStockExhaust = nonStockExhaust
        self.exhaustIsOpened = false
        self.usedTrunkVolume = 0
        self.maximumAmountOfPassengers = maximumAmountOfPassengers
        self.amountOfPassengers = 0
        self.passengersFullName = []
    }
    
    // Пассажиры
    enum PrintNameMode {
        case full
        case middle
        case short
    }
    
    func printPassengersName(mode: PrintNameMode) {
        switch mode {
        case .full:
            for passenger in passengersFullName {
                print(passenger.0, passenger.1, passenger.2)
            }
        case .middle:
            for passenger in passengersFullName {
                print(passenger.1, passenger.2)
            }
        case .short:
            for passenger in passengersFullName {
                print(passenger.0)
            }
        }
    }
    
    mutating func addPassengers(FullName : [(String, String, String)]) {
        if FullName.count + amountOfPassengers <= maximumAmountOfPassengers {
            passengersFullName.append(contentsOf: FullName)
        }
        else { print("Многовато народу! Попробуйте поменьше") }
    }
    
    func openTheRoof() { print("sfx: Wzhhhhhhhhhhhhh-chk.") }
    func catapult() { print("sfx: pshhhhhh-bam!") }
    func closeTheRoof() { "sfx: Chk-wzhhhhhhhhhhhhh-chk." }
    
    mutating func catapultPassengers() {
        openTheRoof()
        catapult()
        passengersFullName = []
        amountOfPassengers = 0
        closeTheRoof()
    }
    
    // Багажник
    mutating func openTrunk() { trunkIsOpened = true }
    
    mutating func closeTrunk() { trunkIsOpened = false }
    
    mutating func addThingsToTheTrunk(volume : Int) {
        if usedTrunkVolume + volume <= trunkVolume { usedTrunkVolume += volume }
        else { print("Многовато, не лезет! Попробуйте положить поменьше")}
    }
    
    mutating func removeThingsFromTheTrunk(volume : Int) {
        if usedTrunkVolume - volume >= 0 { usedTrunkVolume -= volume }
        else { print("Как можно вынуть то, чего нет?...") }
    }
    
    // Окна
    mutating func openWindows() { windowsOpened = true }
    mutating func closeWindows() { windowsOpened = false }
    
    // Выхлоп
    mutating func openTheExhaust() { if nonStockExhaust { exhaustIsOpened = true } }
    
    mutating func closeTheExhaust() {
        if nonStockExhaust {
        exhaustIsOpened = false
        print("Майор, у меня всё сток!")
        }
    }
    
    // Получение информации
    func getVolumeOfLuggage() -> Int { return usedTrunkVolume }
    func getTrunkVolume() -> Int { return trunkVolume }
    
    func getWindowsState() -> Bool {
        if windowsOpened { print("Окна открыты") }
        else { print("Окна закрыты") }
        return windowsOpened }
    
    func getTrunkState() -> Bool {
        if trunkIsOpened { print("Багажник открыт") }
        else { print("Багажник закрыт") }
        return trunkIsOpened
    }
    
    mutating func engineStartStop() {
        if !engineIsOn {
            if carIsElectric {
                print("Haha, those petrolheads!")
                engineIsOn.toggle()
            }
            else {
                if Int.random(in: 0...1) == 0 { print("Engine start failed") }
                else {
                    engineIsOn.toggle()
                    print("sfx: Wroooom th-th-th-th-th-th-th-th")
                }
            }
        }
        else { engineIsOn.toggle() }
    }
    
}


// Обычная машина
var hondaCivic = Car.init(color: "Aegean Blue Metallic", brand: "Honda",
                      manufactureDate: 2019, trunkVolume: 424,
                      carIsElectric: false, maximumAmountOfPassengers: 5,
                      nonStockExhaust: true)
hondaCivic.engineStartStop()
hondaCivic.addPassengers(FullName: [("Петров", "Анатолий", "Генадьевич"),
                                ("Казаков", "Илья", "Вилсакомович")])
hondaCivic.printPassengersName(mode: .short)

print()

// Грузовик
var fordF150 = Car.init(color: "black", brand: "Ford",
                        manufactureDate: 2019, trunkVolume: 2200,
                        carIsElectric: false, maximumAmountOfPassengers: 5,
                        nonStockExhaust: false)
fordF150.openWindows()
fordF150.openTrunk()
fordF150.getTrunkState()
