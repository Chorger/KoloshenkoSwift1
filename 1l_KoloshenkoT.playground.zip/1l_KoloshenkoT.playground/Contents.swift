import Cocoa

// Первое задание
let a : Double = 1
let b : Double = 1
let c : Double = -12

let D : Double = (b * b) - (4 * a * c);

if (D < 0) { print("Нет решения!") }
if (D == 0) { print(sqrt(D) / a * 2) }
if (D > 0) {
    print("Первый корень = ",
        (((b * (-1) + sqrt(D)) / 2 * a)),
        ", Второй корень = ",
        ((b * (-1) - sqrt(D)) / 2 * a))
}
print();

// Второе задание
let firstSide : Double = 3;
let secondSide : Double = 4;

print("Площадь равна ", firstSide * secondSide * 0.5);
print("Периметр равен ", firstSide + secondSide +
    sqrt(firstSide * firstSide + secondSide * secondSide));
print("Гипотенуза равна ", sqrt(firstSide * firstSide + secondSide * secondSide));
print();

// Третье задание
var userSum : Double = 100;
let userPercent : Double = (10) / 100 + 1;
for _ in 0...4 { userSum *= userPercent }
print(Int(userSum));
