import Cocoa

var str = "Hello, playground"
