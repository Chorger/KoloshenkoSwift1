import Cocoa

// Первое задание
let theNumber = 10
theNumber % 2 == 0 ? print("Чётное!") : print("Нечётное!")

// Второе задание
let theNumber2 = 12
theNumber2 % 3 == 0 ? print("Делится!") : print("Не делится!")

// Третье задание
var theArray : [Int] = []
for i in 1...100 { theArray.append(i) }
print(theArray)

// Четвёртое задание
func arrayOrganizer (arrayToOrganize : [Int]) -> [Int] {
    var arrayToReturn : [Int] = []
    for i in 0...(arrayToOrganize.count - 1) {
        if (arrayToOrganize[i] % 2 == 1 && arrayToOrganize[i] % 3 == 0) {
            arrayToReturn.append(arrayToOrganize[i])
        }
    }
    return arrayToReturn
}
print(arrayOrganizer(arrayToOrganize: theArray))

// Пятое задание
func fibonacciNumberAdd (array : [Int]) -> [Int] {
    var arrayToReturn : [Int] = array;
    for i in array[array.count - 1]...(array[array.count - 1] + 99) {
        arrayToReturn.append(getFibonacciNumber(number: i))
    }
    return arrayToReturn
}
func getFibonacciNumber (number : Int) -> Int {
    if (number < 2) { return number }
    else {
        return (getFibonacciNumber(number: (number - 1)) +
            getFibonacciNumber(number: number - 2))
    }
}
// Включать только на производительном ПК,
// количество чисел изменяется согласно золотому сечению.
// print(fibonacciNumberAdd(array: theArray))

// Шестое задание
func getSimpleNumbersTillN (n : Int) -> [Int] {
    var numbersArray : [Bool] = []
    for _ in 0...n { numbersArray.append(true) }
    
    var i : Int = 2
    while (i * i) <= n {
        if numbersArray[i] == true {
            var j = i * i
            while j <= n { numbersArray[j] = false; j += i; }
        }
        i += 1
    }
    var arrayToReturn : [Int] = []
    for i in 0...(numbersArray.count - 1) {
        if numbersArray[i] { arrayToReturn.append(i) }
    }
    return arrayToReturn
}
func getSimpleNumbers(amount : Int) -> [Int] {
    var arrayToReturn : [Int] = []
    arrayToReturn = getSimpleNumbersTillN(n: 541)
    arrayToReturn.removeFirst(2)
    arrayToReturn.removeLast(100 - amount)
    return arrayToReturn
}
print(getSimpleNumbers(amount: 100))
