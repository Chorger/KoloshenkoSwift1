import Cocoa

// Варианты печати имен пассажиров
enum PrintNameMode {
    case full
    case middle
    case short
}

protocol Car {
    var color : String { get }
    var brand : String { get }
    var manufactureDate : Int { get }
    var trunkVolume : Int { get }
    var engineIsOn : Bool { get set }
    var windowsOpened : Bool { get set }
    var trunkIsOpened : Bool { get set }
    var carIsElectric : Bool { get set }
    var usedTrunkVolume : Int { get set }
    var maximumAmountOfPassengers : Int { get }
    var passengersFullName : [(String, String, String)] { get set }
    var amountOfPassengers : Int { get set }
    
    // Пассажиры и всё с ними связанное
    func printPassengersName(mode : PrintNameMode)
    func addPassengers(FullName : [(String, String, String)])
    
    func openTheRoof()
    func catapult()
    func closeTheRoof()
    
    func catapultPassengers()
    
    // Багажник
    func openTrunk()
    func closeTrunk()
    func addThingsToTheTrunk(volume : Int)
    func removeThingsFromTheTrunk(volume : Int)
    
    // Окна
    func openWindows()
    func closeWindows()
    
    // Получение информации
    func getVolumeOfLuggage() -> Int
    func getTrunkVolume() -> Int
    func getWindowsState() -> Bool
    func getTrunkState() -> Bool
    
    // Двигатель
    func engineStartStop()
}

extension Car {
    func printPassengersName(mode: PrintNameMode) {
        switch mode {
        case .full:
            for passenger in passengersFullName {
                print(passenger.0, passenger.1, passenger.2)
            }
        case .middle:
            for passenger in passengersFullName {
                print(passenger.1, passenger.2)
            }
        case .short:
            for passenger in passengersFullName {
                print(passenger.0)
            }
        }
    }
    
    mutating func addPassengers(FullName : [(String, String, String)]) {
        if FullName.count + amountOfPassengers <= maximumAmountOfPassengers {
            passengersFullName.append(contentsOf: FullName)
        }
        else { print("Многовато народу! Попробуйте поменьше") }
    }
    
    func openTheRoof() { print("sfx: Wzhhhhhhhhhhhhh-chk.") }
    func catapult() { print("sfx: pshhhhhh-bam!") }
    func closeTheRoof() { "sfx: Chk-wzhhhhhhhhhhhhh-chk." }
    
    mutating func catapultPassengers() {
        openTheRoof()
        catapult()
        passengersFullName = []
        amountOfPassengers = 0
        closeTheRoof()
    }
    
    // Багажник
    mutating func openTrunk() { trunkIsOpened = true }
    
    mutating func closeTrunk() { trunkIsOpened = false }
    
    mutating func addThingsToTheTrunk(volume : Int) {
        if usedTrunkVolume + volume <= trunkVolume { usedTrunkVolume += volume }
        else { print("Многовато, не лезет! Попробуйте положить поменьше")}
    }
    
    mutating func removeThingsFromTheTrunk(volume : Int) {
        if usedTrunkVolume - volume >= 0 { usedTrunkVolume -= volume }
        else { print("Как можно вынуть то, чего нет?...") }
    }
    
    // Окна
    mutating func openWindows() { windowsOpened = true }
    mutating func closeWindows() { windowsOpened = false }
    
    // Получение информации
    mutating func getVolumeOfLuggage() -> Int { return usedTrunkVolume }
    mutating func getTrunkVolume() -> Int { return trunkVolume }
    
    mutating func getWindowsState() -> Bool {
        if windowsOpened { print("Окна открыты") }
        else { print("Окна закрыты") }
        return windowsOpened }
    
    mutating func getTrunkState() -> Bool {
        if trunkIsOpened { print("Багажник открыт") }
        else { print("Багажник закрыт") }
        return trunkIsOpened
    }
    
    mutating func engineStartStop() {
        if !engineIsOn {
            if carIsElectric {
                print("Haha, those petrolheads!")
                engineIsOn.toggle()
            }
            else {
                if Int.random(in: 0...1) == 0 { print("Engine start failed") }
                else {
                    engineIsOn.toggle()
                    print("sfx: Wroooom th-th-th-th-th-th-th-th")
                }
            }
        }
        else { engineIsOn.toggle() }
    }
}

class SportsCar : Car {
    private var nonStockExhaust : Bool
    private var exhaustIsOpened : Bool
    private var spoilerIsUp : Bool
    private let optionPackage : optionPackages
    
    var color: String
    var brand: String
    var manufactureDate: Int
    var trunkVolume: Int
    var engineIsOn: Bool
    var windowsOpened: Bool
    var trunkIsOpened: Bool
    var carIsElectric: Bool
    var usedTrunkVolume: Int
    var maximumAmountOfPassengers: Int
    var passengersFullName: [(String, String, String)]
    var amountOfPassengers: Int
    
    init(color : String, brand : String, manufactureDate : Int,
         trunkVolume : Int, carIsElectric : Bool,
         maximumAmountOfPassengers : Int,
         nonStockExhaust : Bool, optionPackage : optionPackages) {
        self.nonStockExhaust = nonStockExhaust
        self.exhaustIsOpened = false
        self.spoilerIsUp = false
        self.optionPackage = optionPackage
        self.color = color
        self.brand = brand
        self.manufactureDate = manufactureDate
        self.trunkVolume = trunkVolume
        self.engineIsOn = false
        self.windowsOpened = false
        self.carIsElectric = carIsElectric
        self.trunkIsOpened = false
        self.usedTrunkVolume = 0
        self.maximumAmountOfPassengers = maximumAmountOfPassengers
        self.amountOfPassengers = 0
        self.passengersFullName = []
    }
    
    // Выхлоп
    func openTheExhaust() { if nonStockExhaust { exhaustIsOpened = true } }
    
    func closeTheExhaust() {
        if nonStockExhaust {
            exhaustIsOpened = false
            print("Майор, у меня всё сток!")
        }
    }
    
    // Спойлер
    func raiseTheSpoiler() { spoilerIsUp = true }
    func lowerTheSpoiler() { spoilerIsUp = false }
    
    // Пакеты опций
    enum optionPackages {
        case proxy
        case passion
        case prime
        case brabus
        case xclusive
    }
}

extension SportsCar : CustomStringConvertible {
    var description : String { return "Я - спортивная машина!" }
}

class TrunkCar : Car {
    private var ladderIsRetracted : Bool
    private var listOfFruits = Set<TypesOfFruits>()
    
    var color: String
    var brand: String
    var manufactureDate: Int
    var trunkVolume: Int
    var engineIsOn: Bool
    var windowsOpened: Bool
    var trunkIsOpened: Bool
    var carIsElectric: Bool
    var usedTrunkVolume: Int
    var maximumAmountOfPassengers: Int
    var passengersFullName: [(String, String, String)]
    var amountOfPassengers: Int
    
    init(color: String, brand: String, manufactureDate: Int,
         trunkVolume: Int, carIsElectric: Bool,
         maximumAmountOfPassengers: Int) {
        self.ladderIsRetracted = false
        self.listOfFruits = []
        self.color = color
        self.brand = brand
        self.manufactureDate = manufactureDate
        self.trunkVolume = trunkVolume
        self.engineIsOn = false
        self.windowsOpened = false
        self.carIsElectric = carIsElectric
        self.trunkIsOpened = false
        self.usedTrunkVolume = 0
        self.maximumAmountOfPassengers = maximumAmountOfPassengers
        self.amountOfPassengers = 0
        self.passengersFullName = []
    }
    
    func retractTheLadder() { ladderIsRetracted = true }
    func detractTheLadder() { ladderIsRetracted = false }
    
    // Фрукты и всё с ними связанное
    enum TypesOfFruits {
        case apples
        case peaches
        case bananas
        case blueberries
        case pineapples
        case blackberries
    }
    
    func addTypeOfFruits(type : TypesOfFruits) {
        switch type {
        case .apples:
            listOfFruits.insert(.apples)
        case .peaches:
            listOfFruits.insert(.peaches)
        case .bananas:
            listOfFruits.insert(.bananas)
        case .blueberries:
            listOfFruits.insert(.blueberries)
        case .pineapples:
            listOfFruits.insert(.pineapples)
        case .blackberries:
            listOfFruits.insert(.blackberries)
        }
    }
    
    func getListOfTypesOfFruits() -> Set<TypesOfFruits> { return listOfFruits }
    func unloadTheFruits() { listOfFruits = [] }
    func printTheListOfTypesOfFruits() {
        for fruit in listOfFruits { print(fruit) } }
}

extension TrunkCar : CustomStringConvertible {
    var description: String { return "Я - багажник-машина!" }
}

var car1 = SportsCar(color: "Midnight Blue Metallic", brand: "Smart", manufactureDate: 2018, trunkVolume: 350, carIsElectric: false, maximumAmountOfPassengers: 5, nonStockExhaust: true, optionPackage: .brabus)
car1.raiseTheSpoiler()
car1.openWindows()
car1.getWindowsState()
car1.engineStartStop()
print(car1)

var car2 = TrunkCar(color: "Black", brand: "Mercedes", manufactureDate: 2008, trunkVolume: 1000, carIsElectric: false, maximumAmountOfPassengers: 100)
car2.addTypeOfFruits(type: .apples)
car2.addTypeOfFruits(type: .apples)
car2.addTypeOfFruits(type: .bananas)
car2.printTheListOfTypesOfFruits()
print(car2)
