import Cocoa

extension Array {
    var countMinusOne : Int { return (count - 1) }
}

struct Queue<T> {
    private var elements : [T] = []
    
    mutating func clear() { elements = [] }
    
    mutating func enqueue(newElement : T) {
        elements.append(newElement)
    }
    
    mutating func cpuLoadDequeue() -> T {
        return elements.removeFirst()
    }
    
    func peek() -> T {
        return elements[0]
    }
    
    /**
     Сравнивает очередь с данным массивом и
     возвращает массив с совпадающими элементами
    */
    func compareArrays(array : [T], filter : (T, T) -> Bool) -> [T] {
        var arrayToReturn : [T] = []
        
        if elements.count >= array.count {
            for index in 0...elements.countMinusOne {
                for kindex in 0...array.countMinusOne {
                    if filter(elements[index], array[kindex]) {
                        arrayToReturn.append(elements[index])
                    }
                }
            }
        }
        else {
            for index in 0...array.countMinusOne {
                for kindex in 0...elements.countMinusOne {
                    if filter(array[index], elements[kindex]) {
                        arrayToReturn.append(elements[kindex])
                    }
                }
            }
        }
        return arrayToReturn
    }
    
    /** Если замыкание выдаёт true, элемент удаляется. */
    mutating func filter(filter : (T) -> Bool) {
        var index : Int = 0
        while index <= elements.countMinusOne {
            if filter(elements[index]) {
                elements.remove(at: index)
            }
            else { index += 1 }
        }
    }
    
    /** Возвращает элементы с данными индексами */
    subscript(givenIndexes : Int ...) -> [T] {
        var arrayToReturn : [T] = []
        
        for index in givenIndexes where index < elements.count {
            arrayToReturn.append(elements[index])
        }
        
        return arrayToReturn
    }
    
    /**
     Возвращает элемент с данным индексом или nil,
     если элемента с таким индексом нет.
    */
    subscript(givenIndex : Int) -> T? {
        if givenIndex < elements.count && givenIndex >= 0 {
            return elements[givenIndex]
        }
        else {
            return nil
        }
    }
}

var firstQueue = Queue<Int>()
firstQueue.enqueue(newElement: 10)
firstQueue.enqueue(newElement: 100)
firstQueue.enqueue(newElement: 234)
print(firstQueue.cpuLoadDequeue())
print(firstQueue.peek())
print(firstQueue.compareArrays(array: [234], filter: { $0 == $1 } ))
firstQueue.filter(filter: { $0 % 2 == 0} )
firstQueue.enqueue(newElement: 7)
print(firstQueue.peek())
print(firstQueue[1] ?? "no such element")
