//
//  SnakeBodyPart.swift
//  Snake
//
//  Created by Владислав Фролов on 09/08/2019.
//  Copyright © 2019 Владислав Фролов. All rights reserved.
//

import SpriteKit

class SnakeBodyPart: SKShapeNode {
    
    var diametr: CGFloat = 15.0
    
    init(atPoint point: CGPoint) {
        super.init()
        
        path = UIBezierPath(ovalIn: CGRect(x: 0, y: 0, width: diametr, height: diametr)).cgPath
        
        fillColor = UIColor.green
        strokeColor = UIColor.green
        lineWidth = 5
        
        self.position = point
        
        self.physicsBody = SKPhysicsBody(circleOfRadius: diametr / 2, center: CGPoint(x: diametr / 2, y: diametr / 2))
        self.physicsBody?.isDynamic = true
        self.physicsBody?.categoryBitMask = CollisionCategoties.Snake
        self.physicsBody?.contactTestBitMask = CollisionCategoties.EdgeBody | CollisionCategoties.Apple
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError()
    }
}
