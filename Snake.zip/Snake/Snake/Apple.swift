//
//  Apple.swift
//  Snake
//
//  Created by Владислав Фролов on 09/08/2019.
//  Copyright © 2019 Владислав Фролов. All rights reserved.
//

import SpriteKit

class Apple: SKShapeNode {
    
    convenience init(position: CGPoint) {
        self.init()
        
        path = UIBezierPath(ovalIn: CGRect(x: 0, y: 0, width: 15, height: 15)).cgPath
        
        fillColor = UIColor.red
        strokeColor = UIColor.red
        lineWidth = 5
        
        self.position = position
        self.physicsBody = SKPhysicsBody(circleOfRadius: 7.5, center: CGPoint(x: 7.5, y: 7.5))
        self.physicsBody?.categoryBitMask = CollisionCategoties.Apple
    }
    
}

