//
//  Snake.swift
//  Snake
//
//  Created by Владислав Фролов on 09/08/2019.
//  Copyright © 2019 Владислав Фролов. All rights reserved.
//

import SpriteKit

class Snake: SKShapeNode {
    
    var moveSpeed = 150.0
    var angle: CGFloat = 0.0
    var body = [SnakeBodyPart]()
    
    convenience init(atPoint point: CGPoint) {
        self.init()
        
        let head = SnakeHead(atPoint: point)
        body.append(head)
        addChild(head)
    }
    
    func addBodyPart() {
        let newBodyPart = SnakeBodyPart(atPoint: CGPoint(x: (body.last!.position.x) + 50, y: (body.last!.position.y) + 50))
        body.append(newBodyPart)
        addChild(newBodyPart)
    }
    
    func move(){
        guard !body.isEmpty else { return }
        
        let head = body[0]
        moveHead(head)
        
        for index in 0..<body.count where index > 0 {
            let previousBodyPart = body[index - 1]
            let currentBodyPart = body[index]
            
            moveBodyPart(previousBodyPart, current: currentBodyPart)
        }
    }
    
    func moveHead(_ head: SnakeBodyPart) {
        let x = CGFloat(moveSpeed) * sin(angle)
        let y = CGFloat(moveSpeed) * cos(angle)
        
        let nextPosition = CGPoint(x: head.position.x + x, y: head.position.y + y)
        
//        if head.position.y >  UIScreen.main.bounds.size.height ||
//            head.position.y < 0 ||
//            head.position.x > UIScreen.main.bounds.size.width ||
//            head.position.x < 0
//        {
////            moveSpeed = 0
//            body.removeAll()
//            head = SnakeHead(atPoint: point)
//            body.append(head)
//            addChild(head)
//        }
        
        let moveAction = SKAction.move(to: nextPosition, duration: 1.0)
        head.run(moveAction)
    }
    
    func moveBodyPart(_ previous: SnakeBodyPart, current: SnakeBodyPart) {
        if current.position.y + CGFloat(moveSpeed) >  UIScreen.main.bounds.size.height {
            print("hi there")
        }
        print(current.position.y + CGFloat(moveSpeed))
        let moveAction = SKAction.move(to: CGPoint(x: previous.position.x, y: previous.position.y), duration: 1.0)
        current.run(moveAction)
    }
    
    func moveClockwise() {
        angle += (.pi / 2)
    }
    
    func moveCounterClockwise() {
        angle -= (.pi / 2)
    }
}
