//
//  SnakeHead.swift
//  Snake
//
//  Created by Владислав Фролов on 09/08/2019.
//  Copyright © 2019 Владислав Фролов. All rights reserved.
//

import UIKit

class SnakeHead: SnakeBodyPart {
    
    override init(atPoint point: CGPoint) {
        super.init(atPoint: point)
        
        self.physicsBody?.categoryBitMask = CollisionCategoties.SnakeHead
        self.physicsBody?.contactTestBitMask = CollisionCategoties.EdgeBody | CollisionCategoties.Apple | CollisionCategoties.Snake
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError()
    }
}
