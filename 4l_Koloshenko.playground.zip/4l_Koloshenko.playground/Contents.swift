import Cocoa

class Car {
    private let color : String
    private let brand : String
    private let manufactureDate : Int
    private let trunkVolume : Int
    private var engineIsOn : Bool
    private var windowsOpened : Bool
    private var trunkIsOpened : Bool
    private var carIsElectric : Bool
    private var usedTrunkVolume : Int
    private let maximumAmountOfPassengers : Int
    private var passengersFullName : [(String, String, String)]
    private var amountOfPassengers : Int
    
    init(color : String, brand : String, manufactureDate : Int,
         trunkVolume : Int, carIsElectric : Bool,
         maximumAmountOfPassengers : Int) {
        self.color = color
        self.brand = brand
        self.manufactureDate = manufactureDate
        self.trunkVolume = trunkVolume
        self.engineIsOn = false
        self.windowsOpened = false
        self.carIsElectric = carIsElectric
        self.trunkIsOpened = false
        self.usedTrunkVolume = 0
        self.maximumAmountOfPassengers = maximumAmountOfPassengers
        self.amountOfPassengers = 0
        self.passengersFullName = []
    }
    
    // Пассажиры
    enum PrintNameMode {
        case full
        case middle
        case short
    }
    
    func printPassengersName(mode: PrintNameMode) {
        switch mode {
        case .full:
            for passenger in passengersFullName {
                print(passenger.0, passenger.1, passenger.2)
            }
        case .middle:
            for passenger in passengersFullName {
                print(passenger.1, passenger.2)
            }
        case .short:
            for passenger in passengersFullName {
                print(passenger.0)
            }
        }
    }
    
    func addPassengers(FullName : [(String, String, String)]) {
        if FullName.count + amountOfPassengers <= maximumAmountOfPassengers {
            passengersFullName.append(contentsOf: FullName)
        }
        else { print("Многовато народу! Попробуйте поменьше") }
    }
    
    func openTheRoof() { print("sfx: Wzhhhhhhhhhhhhh-chk.") }
    func catapult() { print("sfx: pshhhhhh-bam!") }
    func closeTheRoof() { "sfx: Chk-wzhhhhhhhhhhhhh-chk." }
    
    func catapultPassengers() {
        openTheRoof()
        catapult()
        passengersFullName = []
        amountOfPassengers = 0
        closeTheRoof()
    }
    
    // Багажник
    func openTrunk() { trunkIsOpened = true }
    
    func closeTrunk() { trunkIsOpened = false }
    
    func addThingsToTheTrunk(volume : Int) {
        if usedTrunkVolume + volume <= trunkVolume { usedTrunkVolume += volume }
        else { print("Многовато, не лезет! Попробуйте положить поменьше")}
    }
    
    func removeThingsFromTheTrunk(volume : Int) {
        if usedTrunkVolume - volume >= 0 { usedTrunkVolume -= volume }
        else { print("Как можно вынуть то, чего нет?...") }
    }
    
    // Окна
    func openWindows() { windowsOpened = true }
    func closeWindows() { windowsOpened = false }
    
    // Получение информации
    func getVolumeOfLuggage() -> Int { return usedTrunkVolume }
    func getTrunkVolume() -> Int { return trunkVolume }
    
    func getWindowsState() -> Bool {
        if windowsOpened { print("Окна открыты") }
        else { print("Окна закрыты") }
        return windowsOpened }
    
    func getTrunkState() -> Bool {
        if trunkIsOpened { print("Багажник открыт") }
        else { print("Багажник закрыт") }
        return trunkIsOpened
    }
    
    func engineStartStop() {
        if !engineIsOn {
            if carIsElectric {
                print("Haha, those petrolheads!")
                engineIsOn.toggle()
            }
            else {
                if Int.random(in: 0...1) == 0 { print("Engine start failed") }
                else {
                    engineIsOn.toggle()
                    print("sfx: Wroooom th-th-th-th-th-th-th-th")
                }
            }
        }
        else { engineIsOn.toggle() }
    }
    
    func funcToOverride() { print("I do one thing") }
}

class SportsCar : Car {
    private var nonStockExhaust : Bool
    private var exhaustIsOpened : Bool
    private var spoilerIsUp : Bool
    private let optionPackage : optionPackages
    
    init(color: String, brand: String, manufactureDate: Int, trunkVolume: Int, carIsElectric: Bool, maximumAmountOfPassengers: Int, nonStockExhaust: Bool, optionPackage : optionPackages) {
        self.nonStockExhaust = nonStockExhaust
        self.exhaustIsOpened = false
        self.spoilerIsUp = false
        self.optionPackage = optionPackage
        super.init(color: color, brand: brand, manufactureDate: manufactureDate,
                   trunkVolume: trunkVolume,
                   carIsElectric: carIsElectric,
                   maximumAmountOfPassengers: maximumAmountOfPassengers)
    }
    
    // Выхлоп
    func openTheExhaust() { if nonStockExhaust { exhaustIsOpened = true } }
    
    func closeTheExhaust() {
        if nonStockExhaust {
            exhaustIsOpened = false
            print("Майор, у меня всё сток!")
        }
    }
    
    // Спойлер
    func raiseTheSpoiler() { spoilerIsUp = true }
    func lowerTheSpoiler() { spoilerIsUp = false }
    
    // Пакеты опций
    enum optionPackages {
        case proxy
        case passion
        case prime
        case brabus
        case xclusive
    }
    
    // Перегрузка
    override func funcToOverride() { print("I do the other thing") }
}

// Багажник-машина?)
class TrunkCar : Car {
    private var ladderIsRetracted : Bool
    private var listOfFruits = Set<TypesOfFruits>()
    
    override init(color: String, brand: String, manufactureDate: Int, trunkVolume: Int, carIsElectric: Bool, maximumAmountOfPassengers: Int) {
        self.ladderIsRetracted = false
        self.listOfFruits = []
        super.init(color: color, brand: brand, manufactureDate: manufactureDate,
                   trunkVolume: trunkVolume, carIsElectric: carIsElectric,
                   maximumAmountOfPassengers: maximumAmountOfPassengers)
    }
    
    func retractTheLadder() { ladderIsRetracted = true }
    func detractTheLadder() { ladderIsRetracted = false }
    
    // Фрукты и всё с ними связанное
    enum TypesOfFruits {
        case apples
        case peaches
        case bananas
        case blueberries
        case pineapples
        case blackberries
    }
    
    func addTypeOfFruits(type : TypesOfFruits) {
        switch type {
        case .apples:
            listOfFruits.insert(.apples)
        case .peaches:
            listOfFruits.insert(.peaches)
        case .bananas:
            listOfFruits.insert(.bananas)
        case .blueberries:
            listOfFruits.insert(.blueberries)
        case .pineapples:
            listOfFruits.insert(.pineapples)
        case .blackberries:
            listOfFruits.insert(.blackberries)
        }
    }
    
    func getListOfTypesOfFruits() -> Set<TypesOfFruits> { return listOfFruits }
    func unloadTheFruits() { listOfFruits = [] }
    func printTheListOfTypesOfFruits() {
        for fruit in listOfFruits { print(fruit) } }
    
    // Перегрузка
    override func funcToOverride() { print("I do the other thing") }
}

var car1 = SportsCar(color: "Midnight Blue Metallic", brand: "Smart", manufactureDate: 2018, trunkVolume: 350, carIsElectric: false, maximumAmountOfPassengers: 5, nonStockExhaust: true, optionPackage: .brabus)
car1.raiseTheSpoiler()
car1.openWindows()
car1.getWindowsState()
car1.engineStartStop()

var car2 = TrunkCar(color: "Black", brand: "Mercedes", manufactureDate: 2008, trunkVolume: 1000, carIsElectric: false, maximumAmountOfPassengers: 100)
car2.addTypeOfFruits(type: .apples)
car2.addTypeOfFruits(type: .apples)
car2.addTypeOfFruits(type: .bananas)
car2.printTheListOfTypesOfFruits()
car2.funcToOverride()
